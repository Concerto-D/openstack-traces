
import math
import yaml
import os, sys
import matplotlib
import numpy as np
matplotlib.use('Agg')
from scipy import stats
import matplotlib.pyplot as plt
from concerto.meta import ReconfigurationPerfAnalyzer

from execo import *
from execo_g5k import *
from execo_engine import *


# Parameters (do not forget the / at the end of the directories)
EXPORT_DIRECTORY = "nogit_analysis/"
RESULTS_DIRECTORY = "nogit_results/"
NB_EXPERIMENTS = 5


def mean (list):
    if len(list) != 0:
        return sum(list)/len(list)
    else:
        return 0


def analyse_experiment(exp, reconf, time_files_pattern=None):
    if time_files_pattern is None:
        time_files_pattern = exp

    perf_analyzer = ReconfigurationPerfAnalyzer(reconf)
    graph = perf_analyzer.get_graph()
    graph.save_as_dot("%sgraph_%s.dot" % (EXPORT_DIRECTORY, exp))
    formula = perf_analyzer.get_exec_time_formula()
    with open("%sformula_%s.txt" % (EXPORT_DIRECTORY, exp), "w") as f:
        f.write(formula.to_string(lambda x: '.'.join(x)))

    times = {
        "cached": average_gantt_times(["%sresults_cached_%s_%d.json" % (RESULTS_DIRECTORY, time_files_pattern, i) for i in range(NB_EXPERIMENTS)]),
        "local": average_gantt_times(["%sresults_local_%s_%d.json" % (RESULTS_DIRECTORY, time_files_pattern, i) for i in range(NB_EXPERIMENTS)]),
        "remote": average_gantt_times(["%sresults_remote_%s_%d.json" % (RESULTS_DIRECTORY, time_files_pattern, i) for i in range(NB_EXPERIMENTS)])
    }

    print("%s:" % exp)
    for scenario, stimes in times.items():
        # Checking that we obtain the same time with graph traversal and formula evaluation
        gt = perf_analyzer.get_exec_time(stimes)
        f = formula.evaluate(stimes)
        if not math.isclose(gt, f, rel_tol=1e-10):
            print("WARNING: Graph traversal time different than formula time!")
            print("- graph traversal   : %f seconds" % perf_analyzer.get_exec_time(stimes))
            print("- formula evaluation: %f seconds" % formula.evaluate(stimes))

        print("- %s : %f" % (scenario, gt))

        title = "%s_%s_theo" % (exp, scenario)
        gc = perf_analyzer.get_gantt_chart(stimes)
        gc.export_json("%sgantt_json_%s.json" % (EXPORT_DIRECTORY, title))
        gc.export_plotly("%sgantt_pdf_%s.pdf" % (EXPORT_DIRECTORY, title), "%s" % title)


def average_gantt_times(filenames):
    """
    :param filenames: iterable of names JSON Gantt charts to load
    :return: a dictionary mapping a tuple (component,transition) to the average duration of the transition in the Gantt
    charts
    """
    from statistics import mean
    times_list = []
    for fn in filenames:
        times_list.append(load_gantt_times(fn))
    times = dict()
    if not filenames:
        return times
    for key in times_list[0]:
        times[key] = mean([inst[key] for inst in times_list])
    return times


def load_gantt_times(filename):
    """
    :param filename: name of the JSON Gantt chart to load
    :return: a dictionary mapping a tuple (component,transition) to the duration of the transition in the Gantt chart
    """
    from json import load
    with open(filename) as f:
        gantt = load(f)
    times = dict()
    for component_name, behaviors in gantt.items():
        for behavior, transitions in behaviors.items():
            assert(behavior == "deploy")
            for transition in transitions:
                transition_name = transition["name"]
                transition_duration = transition["end"]-transition["start"]
                times[(component_name, transition_name)] = transition_duration
    
    return times

def analyze_deployment_times(results):
    arranged_results = {
       test_type:
            { registry:
                [ result["time"]
                    for result in results
                    if (result["params"]["registry"] == registry
                        and result["params"]["test_type"] == test_type
                            and result["failure"] == 0) ]
              for registry in
              [ result["params"]["registry"] for result in results ] }
        for test_type in
        [ result["params"]["test_type"] for result in results ] }

    # Extract test types and registry types from the result file:
    ttypes = tuple(
            sorted(
                arranged_results.keys(),
                key=lambda t: 1 if t == "seq_1t"
                    else (2 if t == "seq_nt4"
                    else (3 if t == "dag_2t"
                    else 4))))

    registries = tuple(
            sorted(
                arranged_results[ttypes[0]].keys(),
                key=lambda r: 1 if r == "remote"
                    else (2 if r == "local"
                    else 3)))

    arranged_means = {}
    arranged_stds = {}

    # Compute means and standard deviations: 
    for registry in registries:
        arranged_means[registry] = {}
        arranged_stds[registry] = {}
        for ttype, tres in arranged_results.items():
            arranged_means[registry][ttype] = mean(tres[registry])
            print(ttype, registry, mean(tres[registry]))
            print(tres[registry])
            arranged_stds[registry][ttype] = np.std(tres[registry])

    # Compute max values:
    max_values = {}
    for registry in registries:
        max_values[registry] = max(arranged_means[registry].values())

    # Populate appropriate structures for matplotlib:
    means={}
    stds={}
    for registry in registries:
        means[registry]=[]
        stds[registry]=[]
        for ttype in ttypes:
            means[registry].append(arranged_means[registry][ttype])
            stds[registry].append(arranged_stds[registry][ttype])

    index = np.arange(len(ttypes))

    return (index, registries)

