.. quickstart:

.. include:: ../../doc/source/user/quickstart.rst
