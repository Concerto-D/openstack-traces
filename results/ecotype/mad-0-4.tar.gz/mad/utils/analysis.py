
import yaml
import os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from execo import *
from execo_g5k import *
from execo_engine import *



def mean (list):
    if len(list) != 0:
        return sum(list)/len(list)
    else:
        return 0


def average_gantt_times(filenames):
    """
    :param filenames: iterable of names JSON Gantt charts to load
    :return: a dictionary mapping a tuple (component,transition) to the average duration of the transition in the Gantt
    charts
    """
    from statistics import mean
    times_list = []
    for fn in filenames:
        times_list.append(load_gantt_times(fn))
    times = dict()
    if not filenames:
        return times
    for key in times_list[0]:
        times[key] = mean([inst[key] for inst in times_list])
    return times


def minimum_gantt_times(filenames):
    """
    :param filenames: iterable of names JSON Gantt charts to load
    :return: a dictionary mapping a tuple (component,transition) to the average duration of the transition in the Gantt
    charts
    """
    times_list = []
    for fn in filenames:
        times_list.append(load_gantt_times(fn))
    times = dict()
    if not filenames:
        return times
    for key in times_list[0]:
        times[key] = min([inst[key] for inst in times_list])
    return times


def maximum_gantt_times(filenames):
    """
    :param filenames: iterable of names JSON Gantt charts to load
    :return: a dictionary mapping a tuple (component,transition) to the average duration of the transition in the Gantt
    charts
    """
    from statistics import mean
    times_list = []
    for fn in filenames:
        times_list.append(load_gantt_times(fn))
    times = dict()
    if not filenames:
        return times
    for key in times_list[0]:
        times[key] = max([inst[key] for inst in times_list])
    return times


def load_gantt_times(filename):
    """
    :param filename: name of the JSON Gantt chart to load
    :return: a dictionary mapping a tuple (component,transition) to the duration of the transition in the Gantt chart
    """
    from json import load
    with open(filename) as f:
        gantt = load(f)
    times = dict()
    for component_name, behaviors in gantt.items():
        for behavior, transitions in behaviors.items():
            assert(behavior == "deploy")
            for transition in transitions:
                transition_name = transition["name"]
                transition_duration = transition["end"]-transition["start"]
                times[(component_name, transition_name)] = transition_duration
    
    return times


def format_results(results):
    formatted_results = {
        assembly:
            { registry:
                [ result["time"]
                    for result in results
                    if (result["params"]["registry"] == registry
                        and result["params"]["test_type"] == assembly
                            and result["failure"] == 0) ]
              for registry in
              [ result["params"]["registry"] for result in results ] }
        for assembly in
        [ result["params"]["test_type"] for result in results ] }

    # Extract assemblies and registries from the result file:
    assemblies = tuple(
            sorted(
                formatted_results.keys(),
                key=lambda t: 1 if t == "seq_1t"
                    else (2 if t == "seq_nt4"
                    else (3 if t == "dag_2t"
                    else 4))))

    registries = tuple(
            sorted(
                formatted_results[assemblies[0]].keys(),
                key=lambda r: 1 if r == "remote"
                    else (2 if r == "local"
                    else 3)))

    num_iterations = 0
    for registry in registries:
        for assembly, tres in formatted_results.items():
            num_iterations = len(tres[registry])

    return (formatted_results, assemblies, registries, num_iterations)


def draw_deployment_charts(formatted_results, transition_results, registries,
        assemblies):
    formatted_means = {}
    formatted_stds = {}

    # Compute means and standard deviations:
    # TODO: check if all tests have same iteration number or warning + count it
    for registry in registries:
        formatted_means[registry] = {}
        formatted_stds[registry] = {}
        for assembly in assemblies:
            tres = formatted_results[assembly]
            formatted_means[registry][assembly] = mean(tres[registry])
            print(assembly, registry, mean(tres[registry]))
            print(tres[registry])
            formatted_stds[registry][assembly] = np.std(tres[registry])

    # Compute max values:
    max_values = {}
    for registry in registries:
        max_values[registry] = max(formatted_means[registry].values())

    # Populate appropriate structures for matplotlib:
    means={}
    stds={}
    for registry in registries:
        means[registry]=[]
        stds[registry]=[]
        for assembly in assemblies:
            means[registry].append(formatted_means[registry][assembly])
            stds[registry].append(formatted_stds[registry][assembly])

    mins = transition_results['minimum']
    maxs = transition_results['maximum']

    index = np.arange(len(assemblies))

    fig, ax = plt.subplots()

    bar_width = 0.25
    linewidth = 0.4
    edgecolor= 'k'
    opacity = 0.6
    error_config = {'ecolor': 'black', 'alpha': 0.8}
    colors = ['b', 'r', 'g', 'm', 'c', 'y', 'k']

    i=0
    avg_rects = {}
    min_max_rects = {}
    for registry in registries:
        # Draw the bars from the average time measured from the benchmark 
        avg_rects[registry] = ax.bar(x = index + i*bar_width,
                            height = means[registry], width = bar_width,
                            alpha=opacity, color=colors[i], yerr=stds[registry],
                            error_kw=error_config, label=registry)# capsize=3)
        # Draw a box displaying min and max values from the performance model
        diff_max_min = [maxi-mini for maxi,mini in zip(maxs[registry].values(),mins[registry].values())]
        min_max_rects[registry] = ax.bar(x = index + i*bar_width,
                            height = diff_max_min, width = bar_width,
                            bottom = list(mins[registry].values()),
                            alpha=1, linewidth=linewidth, # lls='dashed',
                            facecolor="None", edgecolor=edgecolor)
        i=i+1
        # Write the performance ratio over bars
        for rect in avg_rects[registry]:
            height = rect.get_height()
            if height == max_values[registry]:
                txt = 1.0
            else:
                txt = float(height/max_values[registry])
            plt.text(rect.get_x() + rect.get_width()/2.0, height*1.03,
                    '%.2f' % txt, color='gray', ha='center', va='bottom')

    ax.set_xlabel('Assemblies')
    ax.set_ylabel('Time (s)')
    #ax.set_title('Time to deploy OpenStack for different assemblies')
    ax.set_xticks(index + bar_width)
    ax.set_xticklabels(assemblies)
    ax.legend()

    fig.tight_layout()

    return plt

