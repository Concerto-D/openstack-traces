
class MadError(Exception):
    pass


class MadAnsibleError(MadError):
    pass


